﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratornaya_2_Password
{
    public class Password
    {
        protected string password;

        public Password(string password)
        {
            this.password = password;
        }
    }
}
